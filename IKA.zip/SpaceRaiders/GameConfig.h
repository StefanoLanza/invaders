#pragma once

// Game configuration
struct GameConfig
{
	// Console
	int   fontSize;
	// World
	int   worldWidth;
	int   worldHeight;
	int   maxAlienLasers;
	int   maxPlayerLasers;
	// Player
	float playerVelocity;
	float playerFireRate;
	// Alien
	float alienUpdateRate;
	float alienTransformEnergy;
	float alienTransformRate;
	float alienHealth;
	float alienVelocity;
	float alienFireRate;  // #lasers / s
	float alienDownVelocity;
	float betterAlienAcceleration;
	float betterAlienFireRate; // #lasers / s
	float powerUpRate;  // destroyed enemies have a 10% chance to drop a power-up that moves towards the bottom of the screen).
	// Lasers
	float playerLaserVelocity;
	float alienLaserVelocity;
	// Explosions
	float explosionTimer;  // explosion lasts some time  before it disappears
	// Power ups
	float powerUpVelocity;
	float powerUpInvulnerabilityTime;
	// Walls
	int wallMaxHits;
	// Simulation
	float alienWaveInterval; // time between waves [s]
	bool godMode;  // good for testing
	unsigned int randomSeed; // > 0 to specify a fixed random seed for testing

	GameConfig();
};
