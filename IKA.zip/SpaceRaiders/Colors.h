#pragma once

enum class Color
{
	red,
	redIntense,
	green,
	greenIntense,
	blue,
	yellow,
	yellowIntense,
	black,
	white,
	whiteIntense,
	count
};
